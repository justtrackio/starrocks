package io.justtrack.starrocks;

import org.apache.datasketches.memory.Memory;
import org.apache.datasketches.theta.SetOperation;
import org.apache.datasketches.theta.Sketch;
import org.apache.datasketches.theta.Sketches;
import org.apache.datasketches.theta.Union;

import java.nio.ByteBuffer;
import java.util.Base64;

public class ThetaSketchUnion {
    private static final int NOMINAL_ENTRIES = 4096;

    public static class State {
        Union union = SetOperation.builder().setNominalEntries(NOMINAL_ENTRIES).buildUnion();

        public int serializeLength() {
            return 4 + union.getResult().getCompactBytes();
        }
    }

    public State create() {
        return new State();
    }

    public void destroy(State state) {
    }

    public final void update(State state, byte[] val) {
        Sketch sketch = Sketches.wrapSketch(Memory.wrap(val));

        state.union.union(sketch);
    }

    public void serialize(State state, ByteBuffer buff) {
        byte[] serialized = state.union.getResult().toByteArray();

        buff.putInt(serialized.length);
        buff.put(serialized);
    }

    public void merge(State state, ByteBuffer buffer) {
        int len = buffer.getInt();
        byte[] bytes = new byte[len];
        buffer.get(bytes);

        state.union.union(Memory.wrap(bytes));
    }

    public byte[] finalize(State state) {
        return state.union.getResult().toByteArray();
    }
}
